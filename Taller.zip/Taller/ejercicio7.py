import os
os.sytem("clear")
#Ejercicio 7
pas = input("Ingresa la contraseña: ")
if(pas == "secreto123"):
    print("Acceso Permitido")
else:
    print("Acceso Denegado")