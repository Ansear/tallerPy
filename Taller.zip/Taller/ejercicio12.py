import os
os.system("cls")

word = input("Ingrese una palabra: ")

for i in range(len(word)):
    print(word[i])