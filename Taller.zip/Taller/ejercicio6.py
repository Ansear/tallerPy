import os
os.sytem("clear")
#Ejercicio 6
exa = int(input("Ingresa su calificación: "))
if(exa >=60) :
    print(f"Has Aprobado, Calificacion: {exa}")
else:
    print(f"Has Reprobado, Calificacion: {exa}")