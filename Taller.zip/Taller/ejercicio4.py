import os
os.sytem("clear")
#Ejercicio 4
num = int(input("Ingresa un numero: "))
if(num%2 == 0):
    print(f"El numero es par: {num}")